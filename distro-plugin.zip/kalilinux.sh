# This is a default distribution plug-in.
# Do not modify this file as your changes will be overwritten on next update.
# If you want customize installation, please make a copy.
DISTRO_NAME="Kali Linux"


TARBALL_URL['aarch64']="https://archive.org/download/kalilinuxfile/kali-linux-arm64.tar.xz"
TARBALL_SHA256['aarch64']="d75adf500ebbd544cfd61d876123257c6a9708ab5a97856ccaba37e0234c70bf"
TARBALL_URL['arm']="https://archive.org/download/kalilinuxfile/kali-linux-armhf.tar.xz"
TARBALL_SHA256['arm']="9d7e61f8bd014dc4adf048f0dcddd91a882dc2afbfa1d701430517bec789dd5c"
TARBALL_URL['i386']="https://archive.org/download/kalilinuxfile/kali-linux-i386.tar.xz"
TARBALL_SHA256['i386']="0528642e33f6213714f45721bc0bf1811effe70fee01bbf4b4ddfde82fafe349"
TARBALL_URL['amd64']="https://archive.org/download/kalilinuxfile/kali-linux-amd64.tar.xz"
TARBALL_SHA256['amd64']="b439e6d103d38ea32b52452b83e5f547931641a0fcd5b97fff213e534c5d833e"

distro_setup() {
	            # Don't update gvfs-daemons and udisks2
               run_proot_cmd apt-mark hold gvfs-daemons udisks2
	}